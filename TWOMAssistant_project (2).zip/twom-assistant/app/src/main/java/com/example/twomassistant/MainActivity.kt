package com.example.twomassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.luaj.vm2.Globals
import org.luaj.vm2.Varargs
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var scriptBox: EditText
    private lateinit var logBox: TextView
    private var runner: Thread? = null
    private val stopRequested = AtomicBoolean(false)

    private val sample = """print('TWOM Assistant: Lua berjalan!')
for i = 1, 5 do
  print('Tes lokal ke-' .. i)
end
print('Tes selesai.')"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }
        val title = TextView(this).apply {
            text = "TWOM Assistant — Uji Script Lokal"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title, matchWrap())
        val note = TextView(this).apply {
            text = "Contoh ini hanya menguji Lua di dalam aplikasi. Tidak mengendalikan TWOM. Jalankan hanya script yang kamu pahami."
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        root.addView(note, matchWrap())
        scriptBox = EditText(this).apply {
            setText(sample)
            textSize = 14f
            typeface = Typeface.MONOSPACE
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            minLines = 7
            setHorizontallyScrolling(true)
        }
        root.addView(scriptBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val run = Button(this).apply {
            text = "Start / Jalankan"
            setOnClickListener { runScript() }
        }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopRequested.set(true)
                runner?.interrupt()
                appendLog("Permintaan berhenti dikirim.\n")
            }
        }
        buttons.addView(run, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttons, matchWrap())
        val logTitle = TextView(this).apply {
            text = "Log hasil"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 4)
        }
        root.addView(logTitle, matchWrap())
        val scroll = ScrollView(this)
        logBox = TextView(this).apply {
            text = "Siap. Tekan Start untuk menjalankan contoh.\n"
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setPadding(8, 8, 8, 8)
        }
        scroll.addView(logBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    @Synchronized private fun runScript() {
        if (runner?.isAlive == true) {
            appendLog("Script masih berjalan. Tekan Stop terlebih dahulu.\n")
            return
        }
        stopRequested.set(false)
        logBox.text = ""
        val source = scriptBox.text.toString()
        runner = Thread {
            try {
                val globals: Globals = JsePlatform.standardGlobals()
                globals["print"] = object : VarArgFunction() {
                    override fun invoke(args: Varargs): Varargs {
                        val line = (1..args.narg()).joinToString("\t") { args.arg(it).tojstring() }
                        runOnUiThread { appendLog(line + "\n") }
                        return org.luaj.vm2.LuaValue.NIL
                    }
                }
                globals.load(source, "local-test").call()
                if (!stopRequested.get()) runOnUiThread { appendLog("[Selesai]\n") }
            } catch (e: Exception) {
                runOnUiThread { appendLog("[Error] ${e.message ?: e.javaClass.simpleName}\n") }
            }
        }.apply { name = "LuaLocalTest"; start() }
    }

    private fun appendLog(text: String) {
        logBox.append(text)
    }

    override fun onDestroy() {
        stopRequested.set(true)
        runner?.interrupt()
        super.onDestroy()
    }
}

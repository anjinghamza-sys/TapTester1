# TWOM Assistant — Local Lua Test

This project is a minimal Android app that embeds LuaJ and runs a small Lua example locally. It does not automate or control TWOM or other apps.

## Build
Use GitHub Actions workflow `Build TWOM Assistant APK`, or build with JDK 17 and Gradle.

## Safety
Only run scripts you understand. The LuaJ JSE runtime is embedded in the app; this is a prototype for local scripting and is not a sandbox for untrusted scripts. Do not add unknown scripts or credentials.
